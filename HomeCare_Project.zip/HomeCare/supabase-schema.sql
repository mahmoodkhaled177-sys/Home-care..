-- HomeCare database schema for Supabase
-- Run in Supabase Dashboard > SQL Editor.
-- Never expose the service_role key in browser code.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  role text not null default 'patient' check (role in ('patient','nurse','admin')),
  birth_date date,
  phone text,
  sex text,
  blood_type text,
  allergies text,
  medical_history text,
  emergency_contact text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.vitals (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  systolic integer check (systolic between 40 and 300),
  diastolic integer check (diastolic between 20 and 200),
  pulse integer check (pulse between 20 and 250),
  temperature numeric(4,1) check (temperature between 30 and 45),
  spo2 integer check (spo2 between 50 and 100),
  respiratory_rate integer check (respiratory_rate between 1 and 80),
  notes text,
  created_at timestamptz not null default now()
);

create table if not exists public.medications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  dose text not null,
  schedule text not null,
  end_date date,
  instructions text,
  created_at timestamptz not null default now()
);

create table if not exists public.appointments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  provider text,
  appointment_at timestamptz not null,
  location text,
  notes text,
  created_at timestamptz not null default now()
);

create table if not exists public.notes (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  body text not null,
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.vitals enable row level security;
alter table public.medications enable row level security;
alter table public.appointments enable row level security;
alter table public.notes enable row level security;

-- Each signed-in user can read and update only their own profile.
drop policy if exists "profile_select_own" on public.profiles;
create policy "profile_select_own" on public.profiles for select to authenticated using (id = auth.uid());
drop policy if exists "profile_insert_own" on public.profiles;
create policy "profile_insert_own" on public.profiles for insert to authenticated with check (id = auth.uid() and role in ('patient','nurse'));
drop policy if exists "profile_update_own" on public.profiles;
create policy "profile_update_own" on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid() and role in ('patient','nurse'));

-- User-owned health records. Nurse access is intentionally NOT granted by this starter schema.
do $$
declare t text;
begin
  foreach t in array array['vitals','medications','appointments','notes'] loop
    execute format('drop policy if exists %I on public.%I', t || '_select_own', t);
    execute format('create policy %I on public.%I for select to authenticated using (user_id = auth.uid())', t || '_select_own', t);
    execute format('drop policy if exists %I on public.%I', t || '_insert_own', t);
    execute format('create policy %I on public.%I for insert to authenticated with check (user_id = auth.uid())', t || '_insert_own', t);
    execute format('drop policy if exists %I on public.%I', t || '_delete_own', t);
    execute format('create policy %I on public.%I for delete to authenticated using (user_id = auth.uid())', t || '_delete_own', t);
  end loop;
end $$;

create index if not exists vitals_user_created_idx on public.vitals(user_id, created_at desc);
create index if not exists medications_user_created_idx on public.medications(user_id, created_at desc);
create index if not exists appointments_user_date_idx on public.appointments(user_id, appointment_at);
create index if not exists notes_user_created_idx on public.notes(user_id, created_at desc);

-- Create a profile automatically for newly registered users.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public
as $$
begin
  insert into public.profiles (id, full_name, role)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'full_name',''),
    case when new.raw_user_meta_data->>'role' = 'nurse' then 'nurse' else 'patient' end
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

-- IMPORTANT:
-- Do not add nurse/admin cross-user access policies until a consent workflow,
-- verified staff identity, audit logging, and a clinical governance process exist.
