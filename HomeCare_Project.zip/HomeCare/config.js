/*
  إعداد الاتصال بـ Supabase:
  1) أنشئ مشروعًا في https://supabase.com
  2) من Project Settings > API انسخ Project URL و anon/public key.
  3) ضع القيمتين أدناه.
  لا تضع service_role key في هذا الملف أبدًا.
*/
window.HOMECARE_CONFIG = {
  SUPABASE_URL: "PASTE_YOUR_SUPABASE_PROJECT_URL_HERE",
  SUPABASE_ANON_KEY: "PASTE_YOUR_SUPABASE_ANON_KEY_HERE"
};
