(() => {
  "use strict";
  const $ = (s) => document.querySelector(s);
  const $$ = (s) => [...document.querySelectorAll(s)];
  const config = window.HOMECARE_CONFIG || {};
  const configured = window.supabase && config.SUPABASE_URL?.startsWith("https://") &&
    config.SUPABASE_ANON_KEY && !config.SUPABASE_ANON_KEY.startsWith("PASTE_");
  const db = configured ? window.supabase.createClient(config.SUPABASE_URL, config.SUPABASE_ANON_KEY) : null;
  let user = null, profile = null, localMode = !db;
  const cache = { vitals: [], medications: [], appointments: [], notes: [] };

  function toast(message) {
    const el = $("#toast"); el.textContent = message; el.classList.add("show");
    clearTimeout(toast.timer); toast.timer = setTimeout(() => el.classList.remove("show"), 3500);
  }
  function esc(v="") { return String(v).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }
  function formObject(form) { return Object.fromEntries(new FormData(form).entries()); }
  function dateText(v) { if(!v) return "—"; const d = new Date(v); return Number.isNaN(d.getTime()) ? esc(v) : d.toLocaleString("ar-EG"); }
  function setBusy(form, busy) { const b=form.querySelector('[type="submit"]'); if(b){b.disabled=busy;b.dataset.old ||= b.textContent;b.textContent=busy?"جارٍ التنفيذ…":b.dataset.old;} }
  async function request(table, method, payload={}, id=null) {
    if(localMode) {
      if(method==="select") return cache[table] || [];
      if(method==="insert") { const row={...payload,id:crypto.randomUUID(),created_at:new Date().toISOString()}; cache[table].unshift(row); return row; }
      if(method==="delete") { cache[table]=cache[table].filter(x=>x.id!==id); return true; }
      return null;
    }
    let q = db.from(table);
    if(method==="select") { const {data,error}=await q.select("*").order("created_at",{ascending:false}); if(error) throw error; return data||[]; }
    if(method==="insert") { const {data,error}=await q.insert(payload).select().single(); if(error) throw error; return data; }
    if(method==="delete") { const {error}=await q.delete().eq("id",id); if(error) throw error; return true; }
  }
  async function loadProfile() {
    if(localMode) return profile || {full_name:"مستخدم تجريبي",role:"patient"};
    const {data,error}=await db.from("profiles").select("*").eq("id",user.id).maybeSingle();
    if(error) throw error;
    if(!data) {
      const {data:created,error:e}=await db.from("profiles").insert({id:user.id,full_name:user.user_metadata?.full_name||"مستخدم جديد",role:user.user_metadata?.role||"patient"}).select().single();
      if(e) throw e; profile=created;
    } else profile=data;
    return profile;
  }
  function showAuth(tab="login") {
    $("#authView").classList.remove("hidden"); $("#appView").classList.add("hidden"); $("#logoutBtn").classList.add("hidden");
    $$(".tab").forEach(b=>b.classList.toggle("active",b.dataset.authTab===tab));
    $("#loginForm").classList.toggle("hidden",tab!=="login"); $("#signupForm").classList.toggle("hidden",tab!=="signup");
  }
  async function showApp() {
    $("#authView").classList.add("hidden"); $("#appView").classList.remove("hidden"); $("#logoutBtn").classList.remove("hidden");
    profile=await loadProfile();
    $("#welcomeTitle").textContent=`أهلاً، ${profile.full_name||"بك"}`;
    $("#roleLabel").textContent=profile.role==="nurse"?"مساحة الممرض":"مساحة المريض";
    $("#nurseInfo").textContent=profile.full_name||"حساب الممرض";
    $$(".nurse-only").forEach(x=>x.classList.toggle("hidden",profile.role!=="nurse"));
    $("#todayLabel").textContent=new Date().toLocaleDateString("ar-EG",{weekday:"long",day:"numeric",month:"long"});
    await refreshAll();
    navigate("overview");
  }
  function navigate(page) {
    $$(".page").forEach(p=>p.classList.toggle("hidden",p.id!==`page-${page}`));
    $$(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.page===page));
    window.scrollTo({top:0,behavior:"smooth"});
  }
  async function refreshAll() {
    for(const t of Object.keys(cache)) cache[t]=await request(t,"select");
    renderVitals(); renderMeds(); renderAppointments(); renderNotes(); updateStats();
  }
  function updateStats() {
    const v=cache.vitals[0]; $("#statBp").textContent=v?.systolic&&v?.diastolic?`${v.systolic}/${v.diastolic}`:"—";
    $("#statPulse").textContent=v?.pulse||"—"; $("#statMeds").textContent=cache.medications.length;
    $("#statAppointments").textContent=cache.appointments.filter(a=>new Date(a.appointment_at)>=new Date()).length;
    const activity=[...cache.vitals.map(x=>({label:"قراءة علامات حيوية",at:x.created_at})),...cache.medications.map(x=>({label:`إضافة دواء: ${x.name}`,at:x.created_at})),...cache.notes.map(x=>({label:`ملاحظة: ${x.title}`,at:x.created_at}))].sort((a,b)=>new Date(b.at)-new Date(a.at)).slice(0,4);
    $("#recentActivity").innerHTML=activity.length?activity.map(x=>`<p class="activity-line">• ${esc(x.label)} <small>${dateText(x.at)}</small></p>`).join(""):'<div class="empty-state">لا توجد بيانات بعد. ابدأ بإضافة أول قراءة أو موعد.</div>';
  }
  function renderVitals() {
    $("#vitalsList").innerHTML=cache.vitals.length?`<table><thead><tr><th>التاريخ</th><th>الضغط</th><th>النبض</th><th>الحرارة</th><th>الأكسجين</th><th>التنفس</th><th>ملاحظة</th></tr></thead><tbody>${cache.vitals.map(v=>`<tr><td>${dateText(v.created_at)}</td><td>${v.systolic||"—"}/${v.diastolic||"—"}</td><td>${v.pulse||"—"}</td><td>${v.temperature||"—"}</td><td>${v.spo2||"—"}</td><td>${v.respiratory_rate||"—"}</td><td>${esc(v.notes||"—")}</td></tr>`).join("")}</tbody></table>`:'<div class="empty-state">لم يتم تسجيل قياسات.</div>';
  }
  function renderMeds() {
    $("#medicationsList").innerHTML=cache.medications.length?cache.medications.map(m=>`<article class="record-card"><h3>💊 ${esc(m.name)}</h3><p><b>الجرعة:</b> ${esc(m.dose)}</p><p><b>المواعيد:</b> ${esc(m.schedule)}</p><p><b>ينتهي:</b> ${m.end_date?dateText(m.end_date):"غير محدد"}</p><p>${esc(m.instructions||"")}</p><div class="record-actions"><button class="danger-btn" data-delete="medications" data-id="${m.id}">حذف السجل</button></div></article>`).join(""):'<div class="empty-state">لا توجد أدوية مسجلة.</div>';
  }
  function renderAppointments() {
    $("#appointmentsList").innerHTML=cache.appointments.length?cache.appointments.map(a=>`<article class="record-card"><h3>📅 ${esc(a.title)}</h3><p><b>التاريخ:</b> ${dateText(a.appointment_at)}</p><p><b>الجهة:</b> ${esc(a.provider||"—")}</p><p><b>المكان:</b> ${esc(a.location||"—")}</p><p>${esc(a.notes||"")}</p><div class="record-actions"><button class="danger-btn" data-delete="appointments" data-id="${a.id}">حذف الموعد</button></div></article>`).join(""):'<div class="empty-state">لا توجد مواعيد مسجلة.</div>';
  }
  function renderNotes() {
    $("#notesList").innerHTML=cache.notes.length?cache.notes.map(n=>`<article class="record-card"><h3>${esc(n.title)}</h3><p>${esc(n.body)}</p><p>${dateText(n.created_at)}</p><div class="record-actions"><button class="danger-btn" data-delete="notes" data-id="${n.id}">حذف الملاحظة</button></div></article>`).join(""):'<div class="empty-state">لا توجد ملاحظات.</div>';
  }
  async function addRecord(form,table,mapper=(x)=>x) {
    setBusy(form,true);
    try {
      const values=mapper(formObject(form));
      if(!localMode) values.user_id=user.id;
      await request(table,"insert",values); form.reset(); await refreshAll(); toast("تم الحفظ بنجاح.");
    } catch(e) { console.error(e); toast("تعذر الحفظ: "+(e.message||"راجع إعدادات قاعدة البيانات")); }
    finally { setBusy(form,false); }
  }
  function wireForms() {
    $("#profileForm").addEventListener("submit",async e=>{
      e.preventDefault(); const data=formObject(e.currentTarget);
      try {
        if(localMode) profile={...profile,...data};
        else {const {error}=await db.from("profiles").upsert({id:user.id,...data,role:profile.role});if(error)throw error;profile={...profile,...data};}
        $("#welcomeTitle").textContent=`أهلاً، ${profile.full_name}`; toast("تم تحديث الملف الصحي.");
      } catch(err){toast("تعذر حفظ الملف: "+err.message);}
    });
    $("#vitalsForm").addEventListener("submit",e=>{e.preventDefault();addRecord(e.currentTarget,"vitals",v=>Object.fromEntries(Object.entries(v).map(([k,val])=>[k,val===""?null:(["notes"].includes(k)?val:Number(val))])));});
    $("#medForm").addEventListener("submit",e=>{e.preventDefault();addRecord(e.currentTarget,"medications");});
    $("#appointmentForm").addEventListener("submit",e=>{e.preventDefault();addRecord(e.currentTarget,"appointments",v=>({...v,appointment_at:new Date(v.appointment_at).toISOString()}));});
    $("#noteForm").addEventListener("submit",e=>{e.preventDefault();addRecord(e.currentTarget,"notes");});
    document.addEventListener("click",async e=>{
      const del=e.target.closest("[data-delete]");
      if(del&&confirm("هل تريد حذف هذا السجل؟")){try{await request(del.dataset.delete,"delete",{},del.dataset.id);await refreshAll();toast("تم الحذف.");}catch(err){toast("تعذر الحذف: "+err.message);}}
    });
  }
  function exportVitals() {
    const rows=[["التاريخ","الضغط الانقباضي","الضغط الانبساطي","النبض","الحرارة","الأكسجين","التنفس","ملاحظات"],...cache.vitals.map(v=>[v.created_at,v.systolic,v.diastolic,v.pulse,v.temperature,v.spo2,v.respiratory_rate,v.notes])];
    const csv="\uFEFF"+rows.map(r=>r.map(x=>`"${String(x??"").replace(/"/g,'""')}"`).join(",")).join("\n");
    const a=document.createElement("a");a.href=URL.createObjectURL(new Blob([csv],{type:"text/csv;charset=utf-8"}));a.download="homecare-vitals.csv";a.click();URL.revokeObjectURL(a.href);
  }
  function applyTheme(){document.body.classList.toggle("dark",localStorage.getItem("hc-theme")==="dark");}
  async function init() {
    $("#year").textContent=new Date().getFullYear(); applyTheme();
    $("#themeBtn").onclick=()=>{localStorage.setItem("hc-theme",document.body.classList.contains("dark")?"light":"dark");applyTheme();};
    $("#langBtn").onclick=()=>toast("واجهة النسخة الحالية باللغة العربية. إضافة الترجمة الإنجليزية ضمن مرحلة التطوير التالية.");
    $$(".tab").forEach(b=>b.onclick=()=>showAuth(b.dataset.authTab));
    $$(".nav-item").forEach(b=>b.onclick=()=>navigate(b.dataset.page));
    $$("[data-go]").forEach(b=>b.onclick=()=>navigate(b.dataset.go));
    $("#exportVitalsBtn").onclick=exportVitals; $("#logoutBtn").onclick=async()=>{if(db)await db.auth.signOut();user=null;profile=null;showAuth();};
    $("#forgotBtn").onclick=async()=>{const email=$("#loginForm [name=email]").value;if(!email)return toast("اكتب بريدك الإلكتروني أولاً.");if(!db)return toast("استعادة كلمة المرور تتطلب إعداد Supabase.");const {error}=await db.auth.resetPasswordForEmail(email,{redirectTo:location.href});toast(error?error.message:"تم إرسال رابط الاستعادة إذا كان البريد مسجلاً.");};
    $("#loginForm").onsubmit=async e=>{e.preventDefault();const f=e.currentTarget;setBusy(f,true);try{if(localMode){user={email:formObject(f).email,id:"demo-user"};profile={full_name:"مستخدم تجريبي",role:"patient"};toast("أنت تستخدم وضع العرض المحلي. البيانات محفوظة في الذاكرة الحالية فقط.");}else{const {data,error}=await db.auth.signInWithPassword(formObject(f));if(error)throw error;user=data.user;}await showApp();}catch(err){toast(err.message);}finally{setBusy(f,false);}};
    $("#signupForm").onsubmit=async e=>{e.preventDefault();const f=e.currentTarget;setBusy(f,true);try{const v=formObject(f);if(localMode){user={email:v.email,id:"demo-user"};profile={full_name:v.full_name,role:v.role};toast("تم إنشاء جلسة عرض مؤقتة. أعد ضبط Supabase لإنشاء حساب دائم.");}else{const {data,error}=await db.auth.signUp({email:v.email,password:v.password,options:{data:{full_name:v.full_name,role:v.role}}});if(error)throw error;if(!data.session){toast("تم إنشاء الطلب. افحص بريدك لتأكيد الحساب ثم سجّل الدخول.");showAuth("login");return;}user=data.user;profile={full_name:v.full_name,role:v.role};}await showApp();}catch(err){toast(err.message);}finally{setBusy(f,false);}};
    wireForms();
    if(db){const {data}=await db.auth.getSession();if(data.session){user=data.session.user;try{await showApp();}catch(e){console.error(e);showAuth();}}else showAuth();}
    else {showAuth();toast("وضع العرض المحلي يعمل دون قاعدة بيانات. اربط Supabase لتفعيل الحسابات والحفظ الدائم.");}
    if("serviceWorker" in navigator && location.protocol.startsWith("http"))navigator.serviceWorker.register("./service-worker.js").catch(console.warn);
  }
  init();
})();
